package br.edu.ifpe;

public enum Categoria {
	
}
