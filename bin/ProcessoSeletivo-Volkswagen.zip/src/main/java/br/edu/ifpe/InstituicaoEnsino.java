package br.edu.ifpe;

public class InstituicaoEnsino {
	private String nome;
	private String curso;
	private String duracao;
	private int semestreAtual;
	private int numeroMatricula;
	private String endereco;
	private String uf;
	private String cep;
	private String telefone;
	private String telefone2;
	private String coordenador;
	private String email;
	
	public InstituicaoEnsino(String nome, String curso, String duracao, int semestreAtual, int numeroMatricula,
			String endereco, String uf, String cep, String telefone, String telefone2, String coordenador,
			String email) {
		super();
		this.nome = nome;
		this.curso = curso;
		this.duracao = duracao;
		this.semestreAtual = semestreAtual;
		this.numeroMatricula = numeroMatricula;
		this.endereco = endereco;
		this.uf = uf;
		this.cep = cep;
		this.telefone = telefone;
		this.telefone2 = telefone2;
		this.coordenador = coordenador;
		this.email = email;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public String getDuracao() {
		return duracao;
	}

	public void setDuracao(String duracao) {
		this.duracao = duracao;
	}

	public int getSemestreAtual() {
		return semestreAtual;
	}

	public void setSemestreAtual(int semestreAtual) {
		this.semestreAtual = semestreAtual;
	}

	public int getNumeroMatricula() {
		return numeroMatricula;
	}

	public void setNumeroMatricula(int numeroMatricula) {
		this.numeroMatricula = numeroMatricula;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getTelefone2() {
		return telefone2;
	}

	public void setTelefone2(String telefone2) {
		this.telefone2 = telefone2;
	}

	public String getCoordenador() {
		return coordenador;
	}

	public void setCoordenador(String coordenador) {
		this.coordenador = coordenador;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
}
