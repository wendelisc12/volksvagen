package br.edu.ifpe;

import java.util.Date;

public class Candidato {
	private Categoria categoriaEstagio; // enum pra ser feito ainda
	private String nome;
	private String endereco;
	private String uf;
	private String cep;
	private Date dataNascimento;
	private String telefone;
	private String celular;
	private String email;
	public Candidato(Categoria categoriaEstagio, String nome, String endereco, String uf, String cep,
			Date dataNascimento, String telefone, String celular, String email) {
		super();
		this.categoriaEstagio = categoriaEstagio;
		this.nome = nome;
		this.endereco = endereco;
		this.uf = uf;
		this.cep = cep;
		this.dataNascimento = dataNascimento;
		this.telefone = telefone;
		this.celular = celular;
		this.email = email;
	}
	public Categoria getCategoriaEstagio() {
		return categoriaEstagio;
	}
	public void setCategoriaEstagio(Categoria categoriaEstagio) {
		this.categoriaEstagio = categoriaEstagio;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getUf() {
		return uf;
	}
	public void setUf(String uf) {
		this.uf = uf;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public Date getDataNascimento() {
		return dataNascimento;
	}
	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getCelular() {
		return celular;
	}
	public void setCelular(String celular) {
		this.celular = celular;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
			
}
