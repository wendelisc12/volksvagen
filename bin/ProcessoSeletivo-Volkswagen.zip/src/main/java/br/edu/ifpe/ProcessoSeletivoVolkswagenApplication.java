package br.edu.ifpe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProcessoSeletivoVolkswagenApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProcessoSeletivoVolkswagenApplication.class, args);
	}

}
